import React from 'react';
import { Box, Grid, Typography, Paper } from '@mui/material';

const mockData = [
  { id: 1, bloodType: "A+", location: "Delhi", quantity: 2 },
  { id: 2, bloodType: "B-", location: "Mumbai", quantity: 2 },
  { id: 3, bloodType: "O+", location: "Bengaluru", quantity: 1 },
  { id: 4, bloodType: "AB+", location: "Chennai", quantity: 4 }
];

export default function Request() {
  return (
    <Box sx={{ p: 4, backgroundColor: '#121212', minHeight: '100vh' }}>
      <Typography variant="h4" color="white" gutterBottom>All Blood Requests</Typography>
      <Grid container spacing={3}>
        {mockData.map((req) => (
          <Grid item xs={12} sm={6} md={3} key={req.id}>
            <Paper elevation={6} sx={{ p: 2, borderRadius: 3, background: 'linear-gradient(to bottom right, #d32f2f, #880e4f)', color: 'white' }}>
              <Typography variant="h5">{req.bloodType}</Typography>
              <Typography>Location: {req.location}</Typography>
              <Typography>Quantity: {req.quantity} unit{req.quantity > 1 ? 's' : ''}</Typography>
              <Typography>User ID: {req.id}</Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}