import React, { useState } from 'react';
import { TextField, Button, Container, Typography, Box, MenuItem, Paper } from '@mui/material';
import axios from 'axios';
import { useSnackbar } from 'notistack';

const RequestForm = () => {
  const [formData, setFormData] = useState({
    name: "", bloodGroup: "", location: "", quantity: "", userId: ""
  });
  const { enqueueSnackbar } = useSnackbar();

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { name, bloodGroup, location, quantity, userId } = formData;

    if (!name || !bloodGroup || !location || !quantity || !userId) {
      enqueueSnackbar("Please fill in all fields", { variant: "error" });
      return;
    }

    try {
      await axios.post("http://localhost:8000/request/create", formData);
      enqueueSnackbar("Request submitted successfully!", { variant: "success" });
      setFormData({ name: "", bloodGroup: "", location: "", quantity: "", userId: "" });
    } catch (err) {
      enqueueSnackbar("Failed to submit request", { variant: "error" });
    }
  };

  return (
    <Container sx={{ mt: 4 }}>
      <Paper elevation={6} sx={{ p: 4, maxWidth: 500, mx: 'auto', borderRadius: 4 }}>
        <Typography variant="h4" align="center" gutterBottom color="primary">Request Blood</Typography>
        <Box component="form" onSubmit={handleSubmit} sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <TextField label="Name" name="name" value={formData.name} onChange={handleChange} required />
          <TextField select label="Blood Group" name="bloodGroup" value={formData.bloodGroup} onChange={handleChange} required>
            {["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"].map(bg => (
              <MenuItem key={bg} value={bg}>{bg}</MenuItem>
            ))}
          </TextField>
          <TextField label="Location" name="location" value={formData.location} onChange={handleChange} required />
          <TextField label="Quantity (units)" type="number" name="quantity" value={formData.quantity} onChange={handleChange} required />
          <TextField label="User ID" name="userId" value={formData.userId} onChange={handleChange} required />
          <Button variant="contained" type="submit" size="large">Submit</Button>
        </Box>
      </Paper>
    </Container>
  );
};

export default RequestForm;
