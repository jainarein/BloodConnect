import React, { useMemo, useState } from "react";
import { ThemeProvider, createTheme, CssBaseline, IconButton, Box } from "@mui/material";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home";
import RequestForm from "./pages/RequestForm";
import ViewRequests from "./pages/ViewRequests";
import { SnackbarProvider } from "notistack";
import Brightness4Icon from '@mui/icons-material/Brightness4';
import Brightness7Icon from '@mui/icons-material/Brightness7';

export default function AppWrapper() {
  const [mode, setMode] = useState("light");

  const theme = useMemo(
    () =>
      createTheme({
        palette: {
          mode,
          primary: {
            main: "#b71c1c",
          },
        },
      }),
    [mode]
  );

  const toggleColorMode = () => {
    setMode((prev) => (prev === "light" ? "dark" : "light"));
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <SnackbarProvider maxSnack={3}>
        <Router>
          <Box display="flex" justifyContent="space-between" alignItems="center" p={2} bgcolor="background.paper">
            <Box fontWeight="bold" fontSize="1.3rem" color="primary.main">BloodConnect</Box>
            <Box display="flex" alignItems="center" gap={2}>
              <Link to="/" style={{ textDecoration: "none", color: "inherit" }}>Home</Link>
              <Link to="/request" style={{ textDecoration: "none", color: "inherit" }}>View Requests</Link>
              <Link to="/request-blood" style={{ textDecoration: "none", color: "inherit" }}>Request Blood</Link>
              <IconButton onClick={toggleColorMode} color="inherit">
                {mode === "dark" ? <Brightness7Icon /> : <Brightness4Icon />}
              </IconButton>
            </Box>
          </Box>

          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/request" element={<ViewRequests />} />
            <Route path="/request-blood" element={<RequestForm />} />
          </Routes>
        </Router>
      </SnackbarProvider>
    </ThemeProvider>
  );
}
