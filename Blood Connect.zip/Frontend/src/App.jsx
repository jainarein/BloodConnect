import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { CssBaseline, ThemeProvider, createTheme } from '@mui/material';
import Home from './pages/Home';
import Request from './pages/Request';
import Navbar from './components/Navbar';

const theme = createTheme({
  palette: {
    mode: 'dark',
    primary: { main: '#d32f2f' },
    background: { default: '#121212', paper: '#1d1d1d' }
  },
  typography: {
    fontFamily: 'Poppins, sans-serif'
  }
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/request" element={<Request />} />
      </Routes>
    </ThemeProvider>
  );
}

export default App;