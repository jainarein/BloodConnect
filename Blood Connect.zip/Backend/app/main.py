from fastapi import FastAPI
from app.db.database import Base, engine
from app.routers import user, request

app = FastAPI()
Base.metadata.create_all(bind=engine)

app.include_router(user.router, prefix="/user", tags=["User"])
app.include_router(request.router, prefix="/request", tags=["BloodRequest"])