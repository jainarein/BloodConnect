from pydantic import BaseModel
from datetime import datetime

class BloodRequestCreate(BaseModel):
    user_id: int
    blood_group: str
    location: str
    quantity: int
    urgency_level: str

class BloodRequestOut(BaseModel):
    id: int
    user_id: int
    blood_group: str
    location: str
    quantity: int
    urgency_level: str
    status: str
    created_at: datetime

    class Config:
        orm_mode = True