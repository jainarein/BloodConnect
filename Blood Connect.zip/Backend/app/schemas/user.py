from pydantic import BaseModel

class UserCreate(BaseModel):
    name: str
    email: str
    phone: str
    password: str
    blood_group: str
    location: str
    role: str

class UserOut(BaseModel):
    id: int
    name: str
    email: str
    phone: str
    blood_group: str
    location: str
    role: str

    class Config:
        orm_mode = True