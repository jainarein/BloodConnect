from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.schemas import request as schemas
from app.models import request as models
from app.db.database import SessionLocal

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/create", response_model=schemas.BloodRequestOut)
def create_request(request: schemas.BloodRequestCreate, db: Session = Depends(get_db)):
    db_req = models.BloodRequest(**request.dict())
    db.add(db_req)
    db.commit()
    db.refresh(db_req)
    return db_req

@router.get("/all", response_model=list[schemas.BloodRequestOut])
def get_all_requests(db: Session = Depends(get_db)):
    return db.query(models.BloodRequest).all()