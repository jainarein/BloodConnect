import React from 'react';
import { Box, Button, Typography, Stack } from '@mui/material';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <Box
      sx={{
        padding: 4,
        textAlign: 'center',
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #B71C1C, #880E4F, #4A148C)',
        backgroundSize: '600% 600%',
        animation: 'gradientAnimation 15s ease infinite',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        color: '#fff',
      }}
    >
      <Typography variant="h3" gutterBottom sx={{ fontWeight: 'bold' }}>
        Donate Blood. Save Lives.
      </Typography>
      <Typography variant="h6" gutterBottom sx={{ opacity: 0.85 }}>
        A single drop can save a life. Become someone’s hero today.
      </Typography>
      <Stack direction="row" spacing={2} mt={4}>
        <Button component={Link} to="/request-blood" variant="contained" sx={{
          px: 4, py: 1.5, borderRadius: '12px',
          fontWeight: 600, backgroundColor: 'rgba(255, 255, 255, 0.2)',
          color: '#fff', backdropFilter: 'blur(10px)',
          '&:hover': { backgroundColor: 'rgba(255,255,255,0.3)' },
        }}>
          REQUEST BLOOD
        </Button>
        <Button component={Link} to="/request" variant="outlined" sx={{
          px: 4, py: 1.5, borderRadius: '12px',
          fontWeight: 600, color: '#000',
          border: '2px solid #000',
          backgroundColor: 'rgba(255,255,255,0.85)',
          '&:hover': { backgroundColor: '#000', color: '#fff' },
        }}>
          VIEW REQUESTS
        </Button>
      </Stack>
      <style>{`
        @keyframes gradientAnimation {
          0% {background-position: 0% 50%;}
          50% {background-position: 100% 50%;}
          100% {background-position: 0% 50%;}
        }
      `}</style>
    </Box>
  );
}