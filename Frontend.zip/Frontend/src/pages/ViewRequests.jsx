import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, CardContent, Typography, Grid, Container, Avatar, Box, Paper } from '@mui/material';
import BloodtypeIcon from '@mui/icons-material/Bloodtype';

export default function ViewRequests() {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:8000/request/all')
      .then((res) => setRequests(res.data))
      .catch((err) => console.error(err));
  }, []);

  return (
    <Container sx={{ mt: 4 }}>
      <Typography variant="h4" gutterBottom align="center" color="primary">Active Blood Requests</Typography>
      <Grid container spacing={3}>
        {requests.map((req, idx) => (
          <Grid item xs={12} sm={6} md={4} key={idx}>
            <Paper elevation={6} sx={{ borderRadius: 3 }}>
              <Card sx={{ p: 2 }}>
                <Box display="flex" alignItems="center" mb={1}>
                  <Avatar sx={{ bgcolor: 'error.main', mr: 2 }}>
                    <BloodtypeIcon />
                  </Avatar>
                  <Typography variant="h6">{req.bloodGroup}</Typography>
                </Box>
                <CardContent sx={{ pt: 0 }}>
                  <Typography><strong>Location:</strong> {req.location}</Typography>
                  <Typography><strong>Quantity:</strong> {req.quantity} unit(s)</Typography>
                  <Typography><strong>User ID:</strong> {req.userId}</Typography>
                </CardContent>
              </Card>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}